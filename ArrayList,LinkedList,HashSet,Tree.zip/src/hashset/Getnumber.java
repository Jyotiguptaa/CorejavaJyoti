package hashset;
import java.util.*;
public class Getnumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<String> set=new HashSet <String>();
		set.add("Electronics");
		set.add("Laptop");
		set.add("Press");
		//set.size();
		System.out.print(set.size()); //no of element
		
	}

}
