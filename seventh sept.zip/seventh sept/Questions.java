package basicone;

public class Questions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Java Program to Add Two Integers
//		Java Program to substract Two Integers
//		Java Program to Multiply two Floating Point Numbers
//		Java Program to area of reactagle two Floating Point Numbers
//        Java Program to area of square two Floating Point Numbers
//        Java Program to simple Interest using floating points
//        Java Program to area of triangle two Floating Point Numbers
//		
		int num1=7;
		int num2=4;
	    float no1=2.1f;
	    float no2=33.2f;
	    float mul=no1*no2;
		int sum=num1+num2;
		int sub=num1-num2;
		//area of square
		float Side=no2;
		float AreaOfSquare=Side*Side;
		// simple intrest
		float P=22.3f;
		float R=34.2f;
		float T=26.43f;
		float SimpleIntrest=(P*R*T)/100;
		//area of traingle
		float Base=23.3f;
		float Height=54.3f;
		float AreaOfTraingle=(Base*Height)/2;
		System.out.println("Sum of two no is "+sum);
		System.out.println("Sub of two no is "+sub);
		System.out.println("Mul of two no is "+mul);
		System.out.println("Area of Square  "+AreaOfSquare);
		System.out.println("Simple Intrest is "+SimpleIntrest);
		System.out.println("Area of Traingle  "+AreaOfTraingle);
		
		int a=10;
		System.out.println(~a);
		

	}

}
